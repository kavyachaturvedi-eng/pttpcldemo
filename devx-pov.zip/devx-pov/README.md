# DevX UpTime AI — POV + Working Prototype

Complete proof-of-value package for DevX AI Labs' custom industrial AI offering for refining operations.

## What's in this repo

```
devx-pov/
├── index.html            ← Marketing site (positioning POV)
├── vercel.json
├── package.json
├── README.md
└── prototype/
    ├── index.html        ← Interactive Operations Canvas demo
    ├── prototype.css
    ├── prototype.js
    └── SPEAKER_SCRIPT.md ← 12-minute demo script
```

## Two deliverables, one experience

### 1. Marketing POV site (`index.html`)
Cognite-structured positioning site. Sections: Hero, Three Pillars, Problem, Architecture Engine (5 interactive tabs), Agents, Outcomes, Governance, CTA. Zero pricing references — pure outcome-led positioning.

### 2. Interactive Prototype (`prototype/index.html`)
Working clickable Operations Canvas demonstrating all 4 agents end-to-end via one scenario (Sriracha CDU-1 / Pump P-204 / 02:47 AM). Built-in demo HUD with speaker prompts and keyboard navigation.

**7 views, 12-minute walkthrough:**
1. **Dashboard** — Asset health overview, active alerts
2. **Asset Detail** — Live vibration chart, Sentinel detection
3. **Diagnostician** — Animated RCA generation with citations
4. **Memory** — Bilingual incident search, engineer notes
5. **Turnaround Optimizer** — Q3 scope optimization table
6. **Action Handoff** — MOC workflow, approval, audit trail
7. **Outcomes Summary** — Closing recap

## Deploy to Vercel

### Quickest path — CLI

```bash
cd devx-pov
npx vercel --prod
```

The whole folder (marketing site + prototype) deploys as a single static site. The marketing site lives at `/`, the prototype at `/prototype/`.

### Alternative — GitHub + Vercel dashboard

1. Push this directory to GitHub
2. Go to vercel.com/new
3. Import repo — no build settings needed
4. Deploy

### Alternative — Drag and drop

Drag the `devx-pov` folder onto vercel.com/new.

## Using the Prototype for a Live Demo

### Controls
- **Space** or **→** — advance to next demo step
- **←** — previous step
- **H** — toggle the demo HUD on/off

### Workflow
1. Open `/prototype/` in fullscreen browser
2. HUD is visible by default (bottom right)
3. Use keyboard arrows to walk through 7 scripted steps
4. The HUD shows what to say + auto-navigates between views
5. Press H to hide the HUD before screensharing if you want a cleaner look

### Speaker Script
See `prototype/SPEAKER_SCRIPT.md` for the full 12-minute speaker script, including pre-prepared Q&A and presenter tips.

## Customization Pointers

To adapt for a different client or scenario:

**Branding** — colors in CSS `:root` variables (currently signature blue `#2563eb`)

**Scenario** — search `P-204` and `Sriracha CDU-1` to replace with a different asset

**Speaker script** — `SPEAKER_SCRIPT.md` is markdown, easy to edit

**Demo HUD content** — `prototype.js` has `HUD_SCRIPT` constant — edit text/view mappings there

**Citations** — every cited claim in the Diagnostician brief has a `[N]` superscript linked to a citation list. Add/edit citations in the `.rca-section.citations` block of `prototype/index.html`

## Tech Notes

- Pure HTML/CSS/JS — zero build step
- ~120KB total (marketing site + prototype combined)
- No external dependencies except Google Fonts
- Mobile-responsive
- Works offline once loaded
- All 4 agents accessible, all 7 views navigable, all interactions wired

## Architecture Story (for reference)

The prototype demonstrates the 3-layer DevX UpTime AI architecture:

1. **Layer 1 (Ingestion)** — visible as the data sources panel and sensor list (OSIsoft PI, SAP PM, SharePoint, AVEVA E3D, DCS)
2. **Layer 2 (Industrial Data Model)** — visible in the Asset Context panel and Memory's queryable knowledge graph (CFIHOS-aligned)
3. **Layer 3 (AI Agents)** — Sentinel, Diagnostician, Memory, Turnaround Optimizer — each with explicit human-in-the-loop and citation-grounded outputs

The Action Handoff view explicitly shows that no agent action bypasses your existing MOC, SAP work order, or approval processes.

## Compliance Notes

The POV contains **zero pricing, fee, or commercial references**. Every outcome claim is positioned as an industry benchmark range or a description of capability — never a guarantee, never a price quote. Commercial discussions happen offline after the meeting, as they should.
