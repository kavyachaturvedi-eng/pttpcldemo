# DevX UpTime AI — Demo Speaker Script

**Total runtime: ~12 minutes**
**Audience: PTT operations, reliability, digital transformation leadership**
**Anchor scenario: Sriracha CDU-1 · Pump P-204 · 02:47 AM Tuesday**

The prototype has a built-in demo HUD (bottom right corner). Press **Space** or **→** to advance steps, **←** to go back, **H** to hide/show the HUD. The script below corresponds to what the HUD prompts you to do.

---

## Opening (before clicking anything)

> *Let me show you what a reliability engineer at Sriracha refinery actually sees and does when our system is live. This is the day-in-the-life view. Twelve minutes, one real scenario, all four agents working together.*
>
> *The scenario: it's 2:47 AM Tuesday. Pump P-204 — the primary crude feed pump on CDU-1 — has been quietly drifting toward failure for the last two months. Until now, no human knows. Watch what happens.*

---

## Step 1 · Dashboard · ~60 seconds

**[Click into the prototype, land on Dashboard]**

> *Here's the canvas the engineer signs into. Asset health 94 percent. Four active alerts. The critical one — top of the list, pulsing red — is P-204. Sentinel flagged it 11 minutes ago.*
>
> *Three things to notice. First — that little unit map on the right? Every red square is an asset Sentinel is watching live. There's exactly one red one — that's P-204. Second — the four agents at the bottom are all active. Sentinel scanning 487 assets. Diagnostician on standby. Memory holding 2,847 indexed incidents. Turnaround Optimizer working the Q3 scope. Third — top right, the engineer is on night shift, can switch the whole interface to Thai with one click.*
>
> *Engineer sees the red alert. They click in.*

**[Click the P-204 alert]**

---

## Step 2 · Asset Detail · ~2 minutes

**[Auto-lands on Asset Detail view for P-204]**

> *P-204. Sulzer pump. 11 years in service. A1 criticality — meaning no standby. If this pump fails the whole CDU-1 unit goes down. An unplanned shutdown of a unit like this is the kind of event that dominates the operations leadership's worst weeks.*
>
> *The yellow Sentinel banner shows the headline: bearing vibration drift detected, 14 days to action threshold. Confidence rising.*
>
> *Now look at the chart. The blue line is 90 days of bearing vibration. Sixty days ago, baseline 3 mm/sec — totally normal. Then a slow drift. Today, 4.8 mm/sec. The orange dotted line is Sentinel's 14-day forecast — at this rate, we breach the action threshold in 11.3 days.*
>
> *This is the early warning a reactive maintenance approach never sees. Today it's almost certainly missed — the value is still under the alert band. By the time the alarm fires at 7.5 mm/sec, the bearing is already compromised. By failure, the unit is down.*
>
> *On the right — every sensor connected to this pump. Twelve of them. The anomalous one highlighted. Below — the asset's full context from the Industrial Data Model: P&ID drawing reference, last overhaul, criticality class. All of that is queryable, all of it cited.*
>
> *But the engineer doesn't need to manually correlate any of this. They just click Run Diagnostician.*

**[Click "Run Diagnostician"]**

---

## Step 3 · Diagnostician · ~2.5 minutes

**[Lands on Diagnostician view, RCA generation animates]**

> *Watch the top of the screen. Five stages, generating live: pulling 90 days of sensor history, cross-referencing the P&ID and OEM manual, querying Memory for similar past incidents, synthesizing the causal hypothesis, publishing the brief. Twenty-eight seconds end to end.*
>
> *This is what comes out:*
>
> *Headline — probable cause is lubricant degradation leading to early-stage bearing wear. Not just a hypothesis — every claim has a citation. See those little blue numbers in brackets? Each one points to a specific data source: PI tag VT-2031A trend over 90 days, SAP work order WO-2023-08-1147 — the last overhaul, OEM service manual, Memory matches.*
>
> *Critical nuance — the recommendation is **lubricant sample first**, not bearing replacement. Why? Because Memory found three past cases, and in two of them, lubricant change resolved the issue without bearing intervention. That's institutional knowledge stored, surfaced, and acted on.*
>
> *Recommended action breakdown — schedule a lubricant sample within 72 hours, conditional oil change if contamination confirmed, continue Sentinel monitoring, and defer the bearing replacement to the Q3 planned turnaround.*
>
> *Scroll down — all five citations, fully traceable. This isn't a chatbot guessing. Every word is grounded.*
>
> *The engineer wants to see those past incidents. Click "Explore past incidents."*

**[Click "Explore past incidents"]**

---

## Step 4 · Memory · ~2 minutes

**[Lands on Memory view]**

> *This is Memory — your institutional knowledge graph. Two thousand eight hundred forty-seven incidents indexed. Every resolved case from across all four PTT refineries, with engineer notes, attributions, full context. Searchable in Thai and English natively.*
>
> *Top result, similarity 0.91 — this is the most important card on the screen. P-204 itself, 22 months ago. Same exact signature. Resolved by lubricant change in 4.5 hours, no production loss.*
>
> *Look at the yellow box — the engineer note. Quote: "This pump runs hot in monsoon season. We've seen this exact pattern before — always lubricant first, bearing second. Don't replace bearings until you've ruled out oil."*
>
> *That's a senior reliability engineer's pattern recognition, captured at the moment of resolution, attributed to them, and surfaced 22 months later to a night-shift engineer at 2:47 AM. When that senior engineer retires next year, their knowledge stays. That's what Memory unlocks.*
>
> *Second match, P-308 at Rayong, similar pump class — also resolved by oil change. Third match, P-201 in this same unit — caught later in the cycle, required bearing replacement at next turnaround.*
>
> *Three closely-matching cases. The Diagnostician's recommendation is no longer just a hypothesis — it's a pattern.*
>
> *Now let's see what this means for planned maintenance.*

**[Click "Turnaround" in left nav]**

---

## Step 5 · Turnaround Optimizer · ~2 minutes

**[Lands on Turnaround view]**

> *Same engineer, different lens. The Q3 2026 turnaround is 127 days out. The original scope had 312 items.*
>
> *The Turnaround Optimizer agent has been analyzing all 312 items against long-term asset health data — sensor trends, corrosion modeling, past inspection results. It has recommendations.*
>
> *Look at the summary cards: original scope 312, recommended scope 271. Forty-one items deferred. Eight new high-risk items added that Sentinel and Memory surfaced. Net result — turnaround duration drops from 24 days to 20.8 days. **Three point two days shorter**.*
>
> *In the table — P-204 is the first row. Original plan: inspect bearings only. New recommendation: replace bearings and seals. Why? Because Sentinel detected the drift, the Diagnostician deferred the intervention to the turnaround, and now the Turnaround Optimizer knows it has to be in scope.*
>
> *Look at row three — six heat exchangers. Original plan opened and cleaned all six. The Optimizer says defer four, inspect two. Why? Fouling rate analysis shows four are within tolerance. That saves 2.1 days alone.*
>
> *Three point two days of turnaround time at scale. Every shortened day of turnaround flows directly into operational availability and EBITDA contribution. This optimization happens continuously, automatically, with full audit trail.*
>
> *But every recommendation still requires engineer approval. Let's see how that works.*

**[Click "Actions" in left nav]**

---

## Step 6 · Action Handoff · ~1.5 minutes

**[Lands on Action view]**

> *Critical point: nothing autonomous. Every AI recommendation enters your existing change management workflow. Nothing bypasses MOC. Nothing bypasses SAP. Nothing bypasses your engineer.*
>
> *Top — the engineer review card. The Diagnostician's recommendation summarized. Generated by, with confidence level. Risk classification — note: no MOC required for the sample-only step, MOC kicks in automatically if classification crosses the threshold.*
>
> *Right side — the workflow. Sentinel detection done. Diagnostician RCA done. Now awaiting engineer review. After approval: SAP work order auto-created, MOC routed automatically if needed, Memory updated when the incident is resolved.*
>
> *Bottom — full audit trail. Every event with timestamp and source. Sentinel detection at 02:36:14. Engineer opened alert. Diagnostician generation. Every step traceable. This is what explainable AI means in industrial context.*
>
> *Engineer approves.*

**[Click "Approve & create work order"]**

> *Done. Work order WO-2026-05-19-0247 created. Routed to CDU-1 maintenance queue. Audit trail updated. The workflow advances. The next engineer on shift sees a fully contextualized work order. The maintenance team executes. When the case resolves, Memory logs it — and the next engineer at 3 AM in two years time will benefit.*

**[Click "Outcomes" in left nav]**

---

## Step 7 · Outcomes · ~1 minute (closing)

**[Lands on Outcomes view]**

> *Let me close where we started. Twelve minutes, one scenario, four agents.*
>
> *Sentinel — 14 days of early warning. In a reactive model, P-204 fails, CDU-1 stops, 18 hours of unplanned outage. With this — caught at 4.8 mm/sec, scheduled, no production impact.*
>
> *Diagnostician — 28 seconds to a fully cited RCA. Replaces 4 to 8 hours of an engineer cross-referencing five systems manually. Every claim grounded.*
>
> *Memory — institutional knowledge from a retiring senior engineer, surfaced to a night-shift engineer 22 months later, at the exact moment of need.*
>
> *Turnaround Optimizer — 3.2 days off the planned turnaround. Adding the right items, deferring the rest, continuously refining.*
>
> *And the bigger picture: 60 to 70 percent of engineer time today goes to data gathering. That goes back to engineering. Senior expertise scales across shifts. Tacit knowledge stays with you. Every recommendation auditable.*
>
> *This is what custom built around your operations enables. Trained on your assets. Speaks your taxonomy. Native in Thai and English. Runs in your Azure tenant. Open standards, no lock-in. Your operational intelligence, owned by you.*
>
> *The industry benchmark outcome ranges are right there: 20 to 45 percent unplanned downtime reduction, 15 to 30 percent turnaround reduction, 50 percent faster engineer time-to-RCA. Those are the numbers other oil and gas operators have already achieved with comparable custom AI deployments.*
>
> *Pause for questions.*

---

## Likely Q&A — Pre-Prepared Answers

**Q: How is this different from what we'd build with [a platform]?**
> *Three things. First — the data model is custom-fit to your asset taxonomy from day one, not retrofitted. Second — the agents are trained on your specific failure modes, your operating conditions. Third — the operational IP and models stay in your tenant. The architecture is open-standard, so you can adopt complementary platforms anytime without rebuilding.*

**Q: How long to deploy something like this?**
> *Two-day Discovery to scope. Ninety-day pilot on one unit with all four agents live. Refinery-wide rollout in months 4 through 12. The data foundation is built once and scales.*

**Q: What about cyber security and OT/IT segmentation?**
> *Agents sit at Purdue Level 3 with read-only data flows. No control system modifications. Hard boundary at safety-instrumented systems — we never cross IEC 61511 envelope. ISO 27001 and IEC 62443 aligned. Vendor security review supported.*

**Q: Why custom, not buy a platform?**
> *Custom delivery — designed around your specific operational reality — enables outcomes platforms cannot deliver: data residency in your tenant, asset-specific tuning, bilingual day one, architectural optionality, and a delivery model where we own the outcomes alongside you. Different category of solution.*

**Q: How do you handle bad data?**
> *Built-in. Layer 1 of the architecture is data quality remediation — gap-fill, drift correction, tag-rename reconciliation. The data foundation is engineered assuming the data is messy, because it always is.*

**Q: What if a recommendation is wrong?**
> *Two safety nets. First — human-in-the-loop on every recommendation. Nothing executes without engineer approval. Second — every claim is cited. The engineer can trace any conclusion back to the underlying sensor reading or document, see exactly why the agent thinks what it thinks, and accept, modify, or reject.*

---

## Presenter Tips

- **Pacing matters.** 12 minutes feels long if you rush. Pause at the visualizations. Let people read the chart.
- **Don't fight the HUD.** It's there to keep you on script. Trust it.
- **Lean into the moments.** The yellow engineer note in Memory step is the emotional core — slow down on it. The 28-second RCA generation in Step 3 is the visual hero — let it play out.
- **Skip the audit trail row-by-row.** Just say "every event traceable" and let them scan it.
- **Land Step 7 with intention.** That's the close. Don't rush the close.
